public class TravelSystemController {
    public void runDemo() {
        User user = new User("Alice");
        FamilyMember family = new FamilyMember("Bob");
        AutonomousVehicleSystem vehicle = new AutonomousVehicleSystem();
        CommuteAdvisor advisor = new CommuteAdvisor();

        user.requestTravel("Central Park");
        advisor.suggestOptions();
        vehicle.navigateTo("Central Park");
        System.out.println("Vehicle Status: " + vehicle.getStatus());
        family.trackTravelStatus("Alice");
    }
}