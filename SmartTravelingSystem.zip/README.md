# Smart Traveling Management System

## Description
This Java-based system simulates a smart travel management platform where:
- Car owners can autonomously travel without a driver.
- Citizens can receive commute suggestions based on quality, time, and price.
- Family members can track their relatives' travel status in real-time.

## Features
- Autonomous destination routing
- Commute option advisor
- Real-time status tracking by family members

## Technologies
- Java (JDK 8 or higher)

## How to Run

### Requirements
- Install Java JDK (version 8 or higher)
- Install [Visual Studio Code](https://code.visualstudio.com/)
- Install the Java Extension Pack in VS Code

### Steps
1. Extract the zip file into a folder.
2. Open the folder in Visual Studio Code.
3. Open `Main.java`.
4. Click `Run` or press `Ctrl + F5` to execute the program.

You should see a console simulation of the smart travel system.