public class User {
    private String name;

    public User(String name) {
        this.name = name;
    }

    public void requestTravel(String destination) {
        System.out.println(name + " requested autonomous travel to: " + destination);
    }
}