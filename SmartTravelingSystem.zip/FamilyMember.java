public class FamilyMember {
    private String name;

    public FamilyMember(String name) {
        this.name = name;
    }

    public void trackTravelStatus(String relativeName) {
        System.out.println(name + " is tracking travel status of " + relativeName);
    }
}