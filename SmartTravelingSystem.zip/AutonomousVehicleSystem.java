public class AutonomousVehicleSystem {
    public void navigateTo(String destination) {
        System.out.println("Autonomously navigating to " + destination);
    }

    public String getStatus() {
        return "Travel in progress";
    }
}