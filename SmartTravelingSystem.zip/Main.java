public class Main {
    public static void main(String[] args) {
        TravelSystemController controller = new TravelSystemController();
        controller.runDemo();
    }
}